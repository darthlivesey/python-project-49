### Hexlet tests and linter status:
[![Actions Status](https://github.com/darthlivesey/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/darthlivesey/python-project-49/actions)

### Brain-even game demo
https://asciinema.org/a/yKdOxYuuqDlEsPWuwOFCOSI1e

