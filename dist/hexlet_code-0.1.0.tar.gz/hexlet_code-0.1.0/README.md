### Hexlet tests and linter status:
[![Actions Status](https://github.com/darthlivesey/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/darthlivesey/python-project-49/actions)


### Brain-even game demo
https://asciinema.org/a/h53wZV2fXJJbKwI9CS004CAgA


### Brain-calc game demo
https://asciinema.org/a/YN4y0cHc0RBd5QsgpmmIvsYK6


### Brain-gcd game demo
https://asciinema.org/a/IT3MXNBv6pTbnAuiOveGqWWpU


### Brain-progression game demo
https://asciinema.org/a/ZxsRC6m5xIWpo3748thHXCMuP


### Brain-prime game demo
https://asciinema.org/a/zXFz61fZSO2IFyHzXDTN5qnpp