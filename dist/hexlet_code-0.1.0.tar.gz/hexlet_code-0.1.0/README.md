### Hexlet tests and linter status:
[![Actions Status](https://github.com/darthlivesey/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/darthlivesey/python-project-49/actions)


### Brain-even game demo
https://asciinema.org/a/yKdOxYuuqDlEsPWuwOFCOSI1e


### Brain-calc game demo
https://asciinema.org/a/AIyGZGgrZV9q4TG3Id10CIjLM


### Brain-gcd game demo
https://asciinema.org/a/NSo4PdHSr8sqg9wKSgJBthrQX

### Brain-progression game demo
https://asciinema.org/a/ZxsRC6m5xIWpo3748thHXCMuP